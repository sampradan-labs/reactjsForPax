export const CustomMiddleware = store => next => action => {
    console.info("ACTION TRIGGERED: ",action);
    next(action);
}