import { GET_USERS, SET_USERS } from "./Constants";
import {takeEvery, put, call} from 'redux-saga/effects';
import { getUsers } from "./Actions";
import axios from 'axios';

function fetchUsingAxios(){
    return axios.get('https://jsonplaceholder.typicode.com/users')
    .then(response => response.data);
         
}
function fetchUsers(){
    return fetch('https://jsonplaceholder.typicode.com/users').then(response=>response.json());
}
function* GetUsers(){
let data =yield call(fetchUsingAxios);
yield put(getUsers(data));
console.warn('Data from backend');
console.info(data);
}

export function* UserSaga(){
    yield takeEvery(SET_USERS, GetUsers)
}

