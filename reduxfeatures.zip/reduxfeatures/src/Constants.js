export const GET_USERS = 'GET_USERS';
export const SET_USERS = 'SET_USERS';
export const ADD_USER = 'ADD_USER';