import logo from './logo.svg';
import './App.css';
import {useDispatch,useSelector} from 'react-redux';
import { setUsers, addUser } from './Actions';

function App() {
  const dispatch = useDispatch();
  let data = useSelector(state => state.userReducer)
  console.log(data)
  return (
    <>
    <button onClick={()=>dispatch(addUser())}>Add User</button>
    <button onClick={()=>dispatch(setUsers())}>Get Users</button>
    {
      data.map(d=><div>{d.name}</div>)
    }
    </>
  );
}

export default App;
