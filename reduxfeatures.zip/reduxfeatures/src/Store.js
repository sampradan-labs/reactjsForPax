import { userReducer } from "./Reducers";
import {configureStore, combineReducers} from '@reduxjs/toolkit';
import createSagaMiddleware from 'redux-saga';
import {UserSaga} from './UserSaga';
import thunk from "redux-thunk";
import {logger} from 'redux-logger';
import { CustomMiddleware } from "./CustomMiddleware";

const rootreducer = combineReducers({userReducer});
const saga = createSagaMiddleware();
export const store = configureStore({
                            reducer: rootreducer,
                            middleware: [saga,thunk,logger,CustomMiddleware]
                            })
saga.run(UserSaga);