import { GET_USERS,SET_USERS,ADD_USER } from "./Constants";
import { getUsers, setUsers } from "./Actions";

export const userReducer = (prevState=[],action)=>{
    switch (action.type) {
        case GET_USERS:
            console.log(action);
            return [...action.users]
        
        case ADD_USER:
                console.log(action);
                return [...action.payload]    
    
        default:
            return [...prevState]
    }
}