import { GET_USERS,SET_USERS, ADD_USER } from "./Constants"

export const getUsers = (data) => {
    return {
        type:GET_USERS,
        users:data
    }
}

export const setUsers = (data) => {
    return {
        type:SET_USERS,
        users:data
    }
}

//For checking thunk. It enables dispatching async actions
export const addUser = ()=>{

    //This is where Thunk will play the role
    return async(dispatch,getState)=>{
        const response = await fetch('https://jsonplaceholder.typicode.com/users/1');
        const data = await response.json();

        dispatch({
            type: ADD_USER,
            payload: [data]
        })
    }
}