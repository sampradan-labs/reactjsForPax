import { NavLink,useParams } from "react-router-dom";
import React from 'react';

export let C1=(props)=> {
    const {name} = useParams();
  return (
  <div>
    <h3>Namaste {name} This is Project C1</h3>
    <b>We are actively looking for support from. 
      Please click <NavLink to='/login'>here</NavLink> to Login
    </b>
    <ol>
      <li>Sponsors</li>
      <li>Contributors</li>
    </ol>
  </div>)
  }