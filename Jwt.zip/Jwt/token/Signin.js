import React from "react";



function Signin() {
  
  const handleSubmit = (email, password) => {
    //reqres registered sample user
    const loginPayload = {
        "email": "eve.holt@reqres.in",
        "password": "cityslicka"
        }

    fetch("https://reqres.in/api/login", {
        method:'POST',
        body:JSON.stringify(loginPayload),
          headers:{
            'Content-type': 'application/json; charset=UTF-8'
          }      
    })
    .then(res=>res.json())
      .then(jsonRes => {
        //get token from response
        const token = jsonRes.token;

        //set JWT token to local
        localStorage.setItem("token", token);

        //set token to axios common header
        // setAuthToken(token);

        //redirect user to home page
        window.location.href = '/users'

      })
      .catch(err => console.log(err));
  };

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault()
        const [email, password] = event.target.children;
        handleSubmit(email, password);
      }}
    >
      <label for="email">Email</label><br />
      <input type="email" id="email" name="email"/><br />
      <label for="password">Password</label><br />
      <input type="password" id="password" name="password"/><br></br>
      <input type="submit" value="Submit" />
    </form>
  );
}
export default Signin