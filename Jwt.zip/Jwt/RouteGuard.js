import React, { useEffect } from 'react';
import {useNavigate} from 'react-router-dom';
import Signin from './token/Signin';

function RouteGuard(props){
    const {Component} = props;
    const navigate = useNavigate();

    //using react hooks
    useEffect(()=>{
        let token = localStorage.getItem('token');
        if(token == undefined || token == null)
            navigate('/login');
    })
    return (<div>
        <Component/>
    </div>)
}

export default RouteGuard