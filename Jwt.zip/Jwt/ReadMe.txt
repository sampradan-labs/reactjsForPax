Add the files with same folder structure into your react project
Install
>npm install --save react-router-dom

Execute the app
>npm start