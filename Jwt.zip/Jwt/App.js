import logo from './logo.svg';
import './App.css';
import './Jsx'
import { element1, element2, element3, element4 } from './Jsx';
import React from 'react';
import {Navigate, Routes, Route, Router, BrowserRouter, NavLink,useLocation,useParams} from 'react-router-dom'
//importing restricted route file
import  RouteGuard  from './RouteGuard';
import './forRoutes.css'
//import the pages which participate in routing

import { Users } from './http/usingFetch';
import Signin from './token/Signin';
import { Login } from './states';
import { Navbar } from 'react-bootstrap';
import {C1} from './C1'
//De-structuring


export let C2=()=>element2;
export let C3=()=>element3;
export let C4=()=>element4;


function App() {
  return (
    <div>
      
    <BrowserRouter>
    <header>
      <ul>
        <li><NavLink to='/login'>Login</NavLink></li>
        <li><NavLink to='/users'>Users</NavLink></li>
        <li><NavLink to='/c1/Samprada'>C1</NavLink></li>        
    </ul>
    </header> 
    <hr></hr>
    <Routes>
        <Route path="/users" element={<RouteGuard Component={Users}/>}/>
        <Route path="/login"  element={<Signin/>}/>
        <Route path="/c1/:name"  element={<C1/>} />
    </Routes>
</BrowserRouter>
</div>
  );
}

export default App;
